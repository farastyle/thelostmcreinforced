fx_version 'cerulean'
game 'gta5'

this_is_a_map 'yes'

files {
    'stream/*.ymap',
    'stream/*.ytyp'
}

data_file 'DLC_ITYP_REQUEST' 'stream/*.ytyp'